document.addEventListener('DOMContentLoaded', () => {
    const currentUrl = window.location.href;

    if (currentUrl.includes('/Inicio/Registro')) {
        // Carga el script de registro
        registrationModule.init();
    }

    if (currentUrl.includes('/Inicio/Participantes')) {
        // Carga el script de manejo de participantes
        participantsModule.init();
    }

    if (currentUrl.includes('/Inicio/Actualizar')) {
        // Carga el script para actualizar participantes
        updateModule.init();
    }

    if (currentUrl.includes('/Inicio/Progreso') && window.progressModule) {
        progressModule.init();
    }
});
