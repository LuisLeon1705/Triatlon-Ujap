#Proyecto Triatlon para la universidad Jose Antonio Paez
###Desarrollado por:
####-Luis León
####-Andres Rodriguez"# Triatlon-Ujap" 
En el archivo iniciar.txt contiene el comando para iniciar el servidor, se ejecuta en un cmd desde la carpeta donde se localiza el proyecto, esto se puede hacer de manera manual, por ejemplo, cd C:\Users\Usuario\Desktop\ServerReady_Triatlon, despues se ejecuta el comando para iniciar el server, "tpm start", y se habre una pestaña con localhost:30000