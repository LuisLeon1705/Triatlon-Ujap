const express = require('express');
const path = require('path');
const app = express();

// Puerto de escucha
const port = process.env.PORT || 3000;

// Middleware para servir archivos estáticos
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use('/src/Javascript', express.static(path.join(__dirname, 'src/Javascript')));

// Rutas para cada página HTML
app.get('/Inicio', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/Inicio/Participantes', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'participants.html'));
});

app.get('/Inicio/Progreso', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'progress.html'));
});

app.get('/Inicio/Registro', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'registration.html'));
});

app.get('/Inicio/Actualizar', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'updateform.html'));
});

// Redirigir la raíz a /Inicio para una mejor experiencia de usuario
app.get('/', (req, res) => {
  res.redirect('/Inicio');
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${port}`);
});
